# Arduino library for AllSensors DLV Series Low Voltage Digital Pressure Sensors #

This is an Arduino-compatible library for the [AllSensors DLV Series Low Voltage Digital Pressure Sensors](https://www.allsensors.com/products/dlv-series). The library currently supports I²C communications with the sensors.

Currently only the free-running (continuously measuring) variants of the DLV sensors are supported.